from django.apps import AppConfig


class BooksSimpleConfig(AppConfig):
    name = 'books_simple'
