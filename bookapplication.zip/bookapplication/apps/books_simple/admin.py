from django.contrib import admin
from books_simple.models import Book

admin.site.register(Book)