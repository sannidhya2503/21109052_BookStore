from django.apps import AppConfig


class BooksPcFormset2Config(AppConfig):
    name = 'books_pc_formset2'
