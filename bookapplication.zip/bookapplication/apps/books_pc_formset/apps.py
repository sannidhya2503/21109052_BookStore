from django.apps import AppConfig


class BooksPcFormsetConfig(AppConfig):
    name = 'books_pc_formset'
