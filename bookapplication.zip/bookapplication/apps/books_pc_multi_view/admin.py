from django.contrib import admin
from books_pc_multi_view.models import Book, Review

admin.site.register(Book)
admin.site.register(Review)