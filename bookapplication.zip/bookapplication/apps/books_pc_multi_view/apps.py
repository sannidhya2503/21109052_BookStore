from django.apps import AppConfig


class BooksPcMultiViewConfig(AppConfig):
    name = 'books_pc_multi_view'
