from django.contrib import admin
from books_pc_multi_view2.models import Person,Book, Review

admin.site.register(Person)
admin.site.register(Book)
admin.site.register(Review)
