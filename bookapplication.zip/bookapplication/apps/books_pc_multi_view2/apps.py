from django.apps import AppConfig


class BooksPcMultiView2Config(AppConfig):
    name = 'books_pc_multi_view2'
